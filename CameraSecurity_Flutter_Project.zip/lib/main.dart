import 'dart:async';
import 'dart:io';
import 'dart:typed_data';

import 'package:audioplayers/audioplayers.dart';
import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_mlkit_commons/google_mlkit_commons.dart';
import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';

const Color accentGreen = Color(0xFF39FF14);
const Color cyberBlue = Color(0xFF00D9FF);
const String defaultPassword = '11227788';
final ValueNotifier<bool> languageArabic = ValueNotifier<bool>(true);
String tr(String en, String ar) => languageArabic.value ? ar : en;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const CameraSecurityApp());
}

class CameraSecurityApp extends StatelessWidget {
  const CameraSecurityApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<bool>(
      valueListenable: languageArabic,
      builder: (context, arabic, _) => MaterialApp(
      title: 'Camera Security',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF05090F),
        appBarTheme: const AppBarTheme(backgroundColor: Color(0xFF07131B), foregroundColor: cyberBlue, elevation: 0),
        colorScheme: const ColorScheme.dark(
          primary: accentGreen,
          secondary: accentGreen,
          surface: Color(0xFF111A22),
        ),
        useMaterial3: true,
      ),
      builder: (context, child) => Directionality(
        textDirection: arabic ? TextDirection.rtl : TextDirection.ltr,
        child: child ?? const SizedBox.shrink(),
      ),
      home: const LoginPage(),
      ),
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _controller = TextEditingController();
  String _password = defaultPassword;
  String _error = '';

  @override
  void initState() {
    super.initState();
    languageArabic.addListener(_languageChanged);
    _loadPassword();
  }

  void _languageChanged() { if (mounted) setState(() {}); }

  @override
  void dispose() {
    languageArabic.removeListener(_languageChanged);
    _controller.dispose();
    super.dispose();
  }

  Future<void> _loadPassword() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() => _password = prefs.getString('app_password') ?? defaultPassword);
  }

  void _login() {
    if (_controller.text == _password) {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const SecurityHome()),
      );
    } else {
      setState(() => _error = 'Wrong password / كلمة المرور غير صحيحة');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.shield_moon_outlined, color: accentGreen, size: 82),
                  const SizedBox(height: 16),
                  Text(tr('CAMERA SECURITY', 'نظام الكاميرا الأمنية'),
                      style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold, letterSpacing: 2)),
                  Text(tr('Your safety is our priority', 'أمانك أولويتنا'), style: const TextStyle(color: Colors.white70)),
                  const SizedBox(height: 34),
                  TextField(
                    controller: _controller,
                    obscureText: true,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      labelText: tr('Password', 'كلمة المرور'),
                      border: const OutlineInputBorder(),
                      prefixIcon: const Icon(Icons.lock_outline),
                    ),
                    onSubmitted: (_) => _login(),
                  ),
                  const SizedBox(height: 10),
                  Text('${tr('Hint', 'تلميح')}: ${_password.length >= 4 ? _password.substring(0, 2) + '..' + _password.substring(_password.length - 2) : '****'}',
                      style: const TextStyle(color: Colors.white54)),
                  if (_error.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    Text(_error, style: const TextStyle(color: Colors.redAccent)),
                  ],
                  const SizedBox(height: 22),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: _login,
                      icon: const Icon(Icons.login),
                      label: Text(tr('LOGIN', 'دخول')),
                    ),
                  ),
                  TextButton.icon(
                    onPressed: () => languageArabic.value = !languageArabic.value,
                    icon: const Icon(Icons.language),
                    label: Text(tr('العربية', 'English')),
                  ),
                  TextButton(
                    onPressed: () => showAboutDialog(
                      context: context,
                      applicationName: 'Camera Security',
                      applicationVersion: '1.0.0',
                      applicationLegalese: tr('Developer: Hussein Al-Bayati • Instagram: @bgq_v', 'المطوّر: حسين البياتي • إنستغرام: @bgq_v'),
                    ),
                    child: Text(tr('About', 'حول')),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

enum ViewFilter { normal, blackWhite, nightVision }

class SecurityHome extends StatefulWidget {
  const SecurityHome({super.key});
  @override
  State<SecurityHome> createState() => _SecurityHomeState();
}

class _SecurityHomeState extends State<SecurityHome> with WidgetsBindingObserver {
  CameraController? _camera;
  List<CameraDescription> _cameras = [];
  CameraLensDirection _lensDirection = CameraLensDirection.back;
  late final FaceDetector _detector;
  final AudioPlayer _audio = AudioPlayer();
  bool _initializing = true;
  bool _streamBusy = false;
  bool _securityOn = false;
  bool _alarmEnabled = true;
  bool _capturing = false;
  int _faceCount = 0;
  DateTime _lastAlert = DateTime.fromMillisecondsSinceEpoch(0);
  ViewFilter _filter = ViewFilter.normal;
  List<Rect> _faces = [];
  Size _frameSize = Size.zero;
  String _status = 'Preparing camera...';
  List<File> _photos = [];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    languageArabic.addListener(_languageChanged);
    _detector = FaceDetector(
      options: FaceDetectorOptions(
        performanceMode: FaceDetectorMode.fast,
        enableLandmarks: false,
        enableContours: false,
        enableClassification: false,
        enableTracking: true,
      ),
    );
    _start();
    _loadGallery();
  }

  void _languageChanged() { if (mounted) setState(() {}); }

  Future<Directory> _galleryDir() async {
    final docs = await getApplicationDocumentsDirectory();
    final dir = Directory('${docs.path}/CameraSecurity/Gallery');
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir;
  }

  Future<void> _loadGallery() async {
    try {
      final dir = await _galleryDir();
      final files = dir.listSync().whereType<File>()
          .where((f) => f.path.toLowerCase().endsWith('.jpg')).toList()
        ..sort((a, b) => b.path.compareTo(a.path));
      if (mounted) setState(() => _photos = files);
    } catch (_) {}
  }

  Future<void> _start({CameraLensDirection? preferredLens}) async {
    try {
      final status = await Permission.camera.request();
      if (!status.isGranted) {
        if (mounted) setState(() {
          _status = tr('Camera permission denied', 'لم يتم السماح باستخدام الكاميرا');
          _initializing = false;
        });
        return;
      }
      _cameras = await availableCameras();
      if (_cameras.isEmpty) throw Exception('No camera found');
      final wanted = preferredLens ?? _lensDirection;
      final matching = _cameras.where((c) => c.lensDirection == wanted).toList();
      final selected = matching.isNotEmpty ? matching.first : _cameras.first;
      _lensDirection = selected.lensDirection;
      final controller = CameraController(
        selected,
        ResolutionPreset.medium,
        enableAudio: false,
        imageFormatGroup: ImageFormatGroup.yuv420,
      );
      await controller.initialize();
      _camera = controller;
      await controller.startImageStream(_processFrame);
      if (mounted) setState(() {
        _initializing = false;
        _status = tr('Camera ready', 'الكاميرا جاهزة');
      });
    } catch (e) {
      if (mounted) setState(() {
        _initializing = false;
        _status = tr('Camera error: $e', 'خطأ بالكاميرا: $e');
      });
    }
  }

  InputImage? _inputImage(CameraImage image, CameraDescription camera) {
    try {
      if (image.planes.length < 3) return null;
      final width = image.width;
      final height = image.height;
      final yPlane = image.planes[0];
      final uPlane = image.planes[1];
      final vPlane = image.planes[2];
      final nv21 = Uint8List(width * height + (width * height ~/ 2));
      var index = 0;
      for (var row = 0; row < height; row++) {
        final rowStart = row * yPlane.bytesPerRow;
        for (var col = 0; col < width; col++) {
          nv21[index++] = yPlane.bytes[rowStart + col * (yPlane.bytesPerPixel ?? 1)];
        }
      }
      for (var row = 0; row < height ~/ 2; row++) {
        final uStart = row * uPlane.bytesPerRow;
        final vStart = row * vPlane.bytesPerRow;
        for (var col = 0; col < width ~/ 2; col++) {
          nv21[index++] = vPlane.bytes[vStart + col * (vPlane.bytesPerPixel ?? 2)];
          nv21[index++] = uPlane.bytes[uStart + col * (uPlane.bytesPerPixel ?? 2)];
        }
      }
      final rotation = InputImageRotationValue.fromRawValue(camera.sensorOrientation);
      if (rotation == null) return null;
      final metadata = InputImageMetadata(
        size: Size(width.toDouble(), height.toDouble()),
        rotation: rotation,
        format: InputImageFormat.nv21,
        bytesPerRow: width,
      );
      return InputImage.fromBytes(bytes: nv21, metadata: metadata);
    } catch (e) {
      debugPrint('Image conversion error: $e');
      return null;
    }
  }

  Future<void> _processFrame(CameraImage image) async {
    if (_streamBusy || _camera == null || !_camera!.value.isInitialized) return;
    _streamBusy = true;
    try {
      final input = _inputImage(image, _camera!.description);
      if (input == null) {
        if (mounted) setState(() => _status = tr('Face detection input unavailable', 'تعذّر تجهيز صورة كشف الوجه'));
        return;
      }
      final found = await _detector.processImage(input);
      final boxes = found.map((f) => f.boundingBox).toList();
      if (!mounted) return;
      setState(() {
        _faceCount = found.length;
        _faces = boxes;
        _frameSize = Size(image.width.toDouble(), image.height.toDouble());
        _status = found.isEmpty ? tr('Monitoring • No face detected', 'تجري المراقبة • لم يتم كشف وجه') : tr('Person detected • ${found.length}', 'تم كشف شخص • ${found.length}');
      });
      if (_securityOn && found.isNotEmpty &&
          DateTime.now().difference(_lastAlert).inSeconds >= 4 && !_capturing) {
        _lastAlert = DateTime.now();
        unawaited(_alertAndCapture());
      }
    } catch (e) {
      // Keep the camera preview alive if a single frame cannot be processed.
      debugPrint('Face detection frame error: $e');
    } finally {
      _streamBusy = false;
    }
  }

  Future<void> _alertAndCapture() async {
    // Muting affects sound only; face detection and automatic photo capture continue.
    if (_alarmEnabled) {
      try {
        await _audio.stop();
        await _audio.setVolume(1.0);
        await _audio.play(AssetSource('alarm.wav'), volume: 1.0);
      } catch (e) {
        debugPrint('Alarm error: $e');
      }
    }
    await _capture(prefix: 'Alert');
  }

  void _toggleAlarm() {
    setState(() => _alarmEnabled = !_alarmEnabled);
    if (!_alarmEnabled) unawaited(_audio.stop());
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(_alarmEnabled ? tr('Alarm sound enabled', 'تم تشغيل صوت الإنذار') : tr('Alarm muted • Detection remains active', 'تم كتم الإنذار • كاشف الوجوه ما زال يعمل'))),
    );
  }

  Future<void> _capture({String prefix = 'Manual'}) async {
    final camera = _camera;
    if (camera == null || !camera.value.isInitialized || _capturing) return;
    _capturing = true;
    try {
      if (camera.value.isStreamingImages) await camera.stopImageStream();
      await Future.delayed(const Duration(milliseconds: 250));
      final shot = await camera.takePicture();
      final dir = await _galleryDir();
      final stamp = DateTime.now().toIso8601String().replaceAll(':', '-');
      final saved = await File(shot.path).copy('${dir.path}/${prefix}_$stamp.jpg');
      if (mounted) {
        setState(() {
          _photos.insert(0, saved);
          _status = tr('Photo saved', 'تم حفظ الصورة');
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(tr('Photo saved to gallery', 'تم حفظ الصورة في المعرض'))),
        );
      }
    } catch (e) {
      if (mounted) setState(() => _status = tr('Capture error: $e', 'خطأ في التقاط الصورة: $e'));
    } finally {
      try {
        if (mounted && camera.value.isInitialized && !camera.value.isStreamingImages) {
          await camera.startImageStream(_processFrame);
        }
      } catch (e) {
        debugPrint('Could not restart camera stream: $e');
      }
      _capturing = false;
    }
  }

  Future<void> _manualCapture() async {
    if (_capturing) return;
    for (var i = 3; i > 0; i--) {
      if (!mounted) return;
      setState(() => _status = tr('Capture in $i...', 'التقاط الصورة بعد $i...'));
      await Future.delayed(const Duration(seconds: 1));
    }
    await _capture();
  }

  Future<void> _switchCamera() async {
    if (_initializing || _capturing) return;
    final next = _lensDirection == CameraLensDirection.back
        ? CameraLensDirection.front : CameraLensDirection.back;
    setState(() { _initializing = true; _faces = []; _faceCount = 0; _status = tr('Switching camera...', 'جارٍ تبديل الكاميرا...'); });
    final old = _camera;
    _camera = null;
    try {
      if (old != null) {
        if (old.value.isStreamingImages) await old.stopImageStream();
        await old.dispose();
      }
    } catch (e) { debugPrint('Camera dispose error: $e'); }
    await _start(preferredLens: next);
  }

  void _toggleSecurity() {
    setState(() {
      _securityOn = !_securityOn;
      _status = _securityOn ? tr('Security enabled - monitoring faces', 'تم تفعيل الحماية - مراقبة الوجوه') : tr('Security disabled', 'تم إيقاف الحماية');
    });
  }

  Future<void> _changePassword() async {
    final field = TextEditingController();
    final value = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(tr('Change password', 'تغيير كلمة المرور')),
        content: TextField(
          controller: field,
          obscureText: true,
          decoration: InputDecoration(hintText: tr('New password', 'كلمة المرور الجديدة')),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: Text(tr('Cancel', 'إلغاء'))),
          FilledButton(onPressed: () => Navigator.pop(context, field.text.trim()), child: Text(tr('Save', 'حفظ'))),
        ],
      ),
    );
    if (value != null && value.isNotEmpty) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('app_password', value);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(tr('Password updated', 'تم تحديث كلمة المرور'))),
      );
    }
    field.dispose();
  }

  void _showGallery() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => SafeArea(
        child: SizedBox(
          height: MediaQuery.of(context).size.height * .75,
          child: _photos.isEmpty
              ? Center(child: Text(tr('No photos yet', 'لا توجد صور بعد')))
              : GridView.builder(
                  padding: const EdgeInsets.all(12),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2, crossAxisSpacing: 10, mainAxisSpacing: 10,
                  ),
                  itemCount: _photos.length,
                  itemBuilder: (_, i) => ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: Image.file(_photos[i], fit: BoxFit.cover),
                  ),
                ),
        ),
      ),
    );
  }

  ColorFilter? get _colorFilter {
    switch (_filter) {
      case ViewFilter.normal:
        return null;
      case ViewFilter.blackWhite:
        return const ColorFilter.matrix(<double>[
          0.2126, 0.7152, 0.0722, 0, 0,
          0.2126, 0.7152, 0.0722, 0, 0,
          0.2126, 0.7152, 0.0722, 0, 0,
          0, 0, 0, 1, 0,
        ]);
      case ViewFilter.nightVision:
        return const ColorFilter.matrix(<double>[
          0.10, 0.20, 0.05, 0, 0,
          0.25, 1.20, 0.10, 0, 0,
          0.05, 0.35, 0.08, 0, 0,
          0, 0, 0, 1, 0,
        ]);
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final camera = _camera;
    if (camera == null) return;
    if (state == AppLifecycleState.inactive || state == AppLifecycleState.paused) {
      camera.dispose();
      _camera = null;
    } else if (state == AppLifecycleState.resumed) {
      _start();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    languageArabic.removeListener(_languageChanged);
    _camera?.dispose();
    _detector.close();
    _audio.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final camera = _camera;
    return Scaffold(
      appBar: AppBar(
        title: Text(tr('◈ CAMERA SECURITY', '◈ نظام المراقبة الأمنية'), style: const TextStyle(color: cyberBlue, fontWeight: FontWeight.bold, letterSpacing: 1.1)),
        actions: [
          IconButton(tooltip: tr('Switch language', 'تغيير اللغة'), onPressed: () => languageArabic.value = !languageArabic.value, icon: const Icon(Icons.language)),
          IconButton(
            tooltip: tr('About', 'حول'),
            onPressed: () => showAboutDialog(
              context: context,
              applicationName: 'Camera Security',
              applicationVersion: '1.0.0',
              applicationLegalese: tr('Developer: Hussein Al-Bayati • Instagram: @bgq_v', 'المطوّر: حسين البياتي • إنستغرام: @bgq_v'),
            ),
            icon: const Icon(Icons.info_outline),
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 6, 14, 10),
              child: Row(
                children: [
                  Icon(Icons.circle, size: 11, color: _securityOn ? accentGreen : Colors.redAccent),
                  const SizedBox(width: 8),
                  Expanded(child: Text(_securityOn ? tr('SECURITY ON', 'الحماية مفعّلة') : tr('SECURITY OFF', 'الحماية متوقفة'),
                      style: const TextStyle(fontWeight: FontWeight.bold, color: cyberBlue))),
                  Text('${tr('AI FACES', 'وجوه AI')}: $_faceCount', style: const TextStyle(color: accentGreen, fontWeight: FontWeight.bold)),
                ],
              ),
            ),
            Expanded(
              child: Container(
                margin: const EdgeInsets.symmetric(horizontal: 12),
                decoration: BoxDecoration(
                  color: Colors.black,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: cyberBlue.withValues(alpha: .65), width: 1.4),
                ),
                clipBehavior: Clip.antiAlias,
                child: _initializing
                    ? const Center(child: CircularProgressIndicator())
                    : camera != null && camera.value.isInitialized
                        ? Stack(
                            fit: StackFit.expand,
                            children: [
                              _colorFilter == null
                                  ? CameraPreview(camera)
                                  : ColorFiltered(
                                      colorFilter: _colorFilter!,
                                      child: CameraPreview(camera),
                                    ),
                              if (_faces.isNotEmpty && _frameSize != Size.zero)
                                CustomPaint(painter: FaceBoxPainter(_faces, _frameSize)),
                              if (_faceCount > 0)
                                Positioned(
                                  top: 14, left: 14,
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                                    decoration: BoxDecoration(color: Colors.black.withValues(alpha: .78), border: Border.all(color: Colors.redAccent), borderRadius: BorderRadius.circular(8)),
                                    child: Text(tr('AI • FACE DETECTED', 'ذكاء اصطناعي • تم كشف وجه'), style: const TextStyle(color: Colors.redAccent, fontWeight: FontWeight.bold)),
                                  ),
                                ),
                            ],
                          )
                        : Center(
                            child: Padding(
                              padding: const EdgeInsets.all(20),
                              child: Text(_status, textAlign: TextAlign.center),
                            ),
                          ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 12, 14, 4),
              child: Text(_status, maxLines: 2, textAlign: TextAlign.center,
                  style: const TextStyle(color: cyberBlue, fontWeight: FontWeight.w600)),
            ),
            Padding(
              padding: const EdgeInsets.all(12),
              child: Wrap(
                alignment: WrapAlignment.center,
                spacing: 8,
                runSpacing: 8,
                children: [
                  FilledButton.icon(
                    onPressed: _toggleSecurity,
                    icon: Icon(_securityOn ? Icons.shield : Icons.shield_outlined),
                    label: Text(_securityOn ? tr('Security ON', 'الحماية مفعّلة') : tr('Security OFF', 'تفعيل الحماية')),
                    style: FilledButton.styleFrom(
                      backgroundColor: _securityOn ? Colors.green.shade800 : Colors.red.shade900,
                    ),
                  ),
                  OutlinedButton.icon(
                    onPressed: _initializing ? null : _switchCamera,
                    icon: const Icon(Icons.cameraswitch),
                    label: Text(tr('Flip camera', 'قلب الكاميرا')),
                  ),
                  OutlinedButton.icon(
                    onPressed: _toggleAlarm,
                    icon: Icon(_alarmEnabled ? Icons.volume_up : Icons.volume_off),
                    label: Text(_alarmEnabled ? tr('Alarm sound ON', 'صوت الإنذار يعمل') : tr('Alarm muted', 'كتم الإنذار')),
                    style: OutlinedButton.styleFrom(foregroundColor: _alarmEnabled ? accentGreen : cyberBlue, side: BorderSide(color: _alarmEnabled ? accentGreen : cyberBlue)),
                  ),
                  FilledButton.icon(
                    onPressed: _capturing ? null : _manualCapture,
                    icon: const Icon(Icons.camera_alt),
                    label: Text(tr('Capture', 'التقاط صورة')),
                  ),
                  OutlinedButton.icon(
                    onPressed: _showGallery,
                    icon: const Icon(Icons.photo_library_outlined),
                    label: Text(tr('Gallery', 'المعرض')),
                  ),
                  OutlinedButton.icon(
                    onPressed: _changePassword,
                    icon: const Icon(Icons.password),
                    label: Text(tr('Password', 'كلمة المرور')),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(bottom: 14, left: 12, right: 12),
              child: SegmentedButton<ViewFilter>(
                segments: [
                  ButtonSegment(value: ViewFilter.normal, label: Text(tr('Normal', 'عادي'))),
                  ButtonSegment(value: ViewFilter.blackWhite, label: Text(tr('B&W', 'أبيض وأسود'))),
                  ButtonSegment(value: ViewFilter.nightVision, label: Text(tr('Night', 'ليلي'))),
                ],
                selected: {_filter},
                onSelectionChanged: (s) => setState(() => _filter = s.first),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class FaceBoxPainter extends CustomPainter {
  FaceBoxPainter(this.faces, this.sourceSize);
  final List<Rect> faces;
  final Size sourceSize;

  @override
  void paint(Canvas canvas, Size size) {
    if (sourceSize.width <= 0 || sourceSize.height <= 0) return;
    final sx = size.width / sourceSize.width;
    final sy = size.height / sourceSize.height;
    final scale = sx > sy ? sx : sy;
    final dx = (size.width - sourceSize.width * scale) / 2;
    final dy = (size.height - sourceSize.height * scale) / 2;
    final paint = Paint()
      ..color = accentGreen
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3;
    final label = TextPainter(textDirection: TextDirection.ltr);
    for (final face in faces) {
      final rect = Rect.fromLTRB(
        face.left * scale + dx, face.top * scale + dy,
        face.right * scale + dx, face.bottom * scale + dy,
      );
      canvas.drawRect(rect, paint);
      label.text = TextSpan(
        text: tr('Enemy', 'شخص'),
        style: TextStyle(color: Colors.redAccent, fontSize: 15, fontWeight: FontWeight.bold),
      );
      label.layout();
      label.paint(canvas, Offset(rect.left, (rect.top - label.height - 3).clamp(0, size.height)));
    }
  }

  @override
  bool shouldRepaint(covariant FaceBoxPainter oldDelegate) =>
      oldDelegate.faces != faces || oldDelegate.sourceSize != sourceSize;
}
