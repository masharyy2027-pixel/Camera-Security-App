# Camera Security - Cyber Edition

- Cybersecurity visual theme: near-black panels, neon green and cyan highlights.
- On-device AI face detection using Google ML Kit; draws a box around each detected face and shows the face count. This detects faces, not identities.
- Security ON/OFF controls automatic alerting and capture.
- Independent alarm mute/unmute: muting disables sound only. Face detection and automatic alert-photo capture remain active while Security is ON.
- Front/back camera switching.
- Arabic/English toggle, password, gallery, manual capture, and Normal / Black & White / Green Night Vision filters.

Build with the included GitHub Actions workflow. The project should be built and tested on the target Android phone; camera behavior varies by device.

Default password: `12345` (shown on the login screen; users can change it in Settings).


## Photo handling update
- Captured photos are stored in the app's private CameraSecurity/Gallery folder.
- The app also requests Android gallery access and exports each processed image to the
  device photo gallery in the `Camera Security` album.
- The selected preview filter is baked into the saved JPEG (Normal, Black & White,
  or Green Night Vision).
- Tap a thumbnail in the in-app gallery to open the full-screen zoomable photo viewer.

Face detection uses Google ML Kit in accurate mode. The app tracks faces across frames,
plays the alarm once when a new tracked face is detected while Security is ON, and
captures at most 10 successful photos for each tracked face while it remains in view.
The face overlay uses a neon surveillance reticle. Camera frame conversion respects
YUV plane row/pixel strides and device orientation. Actual camera alignment and
performance must still be verified on the target Android phone.
