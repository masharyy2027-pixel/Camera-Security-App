import 'dart:async';
import 'dart:io';
import 'dart:typed_data';

import 'package:audioplayers/audioplayers.dart';
import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:gal/gal.dart';
import 'package:image/image.dart' as img;
import 'package:google_mlkit_commons/google_mlkit_commons.dart';
import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';

const Color accentGreen = Color(0xFF39FF14);
const Color cyberBlue = Color(0xFF00D9FF);
const String defaultPassword = '12345';
final ValueNotifier<bool> languageArabic = ValueNotifier<bool>(true);
String tr(String en, String ar) => languageArabic.value ? ar : en;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const CameraSecurityApp());
}

class CameraSecurityApp extends StatelessWidget {
  const CameraSecurityApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<bool>(
      valueListenable: languageArabic,
      builder: (context, arabic, _) => MaterialApp(
      title: 'Camera Security',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF05090F),
        appBarTheme: const AppBarTheme(backgroundColor: Color(0xFF07131B), foregroundColor: cyberBlue, elevation: 0),
        colorScheme: const ColorScheme.dark(
          primary: accentGreen,
          secondary: accentGreen,
          surface: Color(0xFF111A22),
        ),
        useMaterial3: true,
      ),
      builder: (context, child) => Directionality(
        textDirection: arabic ? TextDirection.rtl : TextDirection.ltr,
        child: child ?? const SizedBox.shrink(),
      ),
      home: const LoginPage(),
      ),
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _controller = TextEditingController();
  String _password = defaultPassword;
  String _error = '';

  @override
  void initState() {
    super.initState();
    languageArabic.addListener(_languageChanged);
    _loadPassword();
  }

  void _languageChanged() { if (mounted) setState(() {}); }

  @override
  void dispose() {
    languageArabic.removeListener(_languageChanged);
    _controller.dispose();
    super.dispose();
  }

  Future<void> _loadPassword() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() => _password = prefs.getString('app_password_v2') ?? defaultPassword);
  }

  void _login() {
    if (_controller.text == _password) {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const SecurityHome()),
      );
    } else {
      setState(() => _error = 'Wrong password / كلمة المرور غير صحيحة');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.shield_moon_outlined, color: accentGreen, size: 82),
                  const SizedBox(height: 16),
                  Text(tr('CAMERA SECURITY', 'نظام الكاميرا الأمنية'),
                      style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold, letterSpacing: 2)),
                  Text(tr('Your safety is our priority', 'أمانك أولويتنا'), style: const TextStyle(color: Colors.white70)),
                  const SizedBox(height: 34),
                  TextField(
                    controller: _controller,
                    obscureText: true,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      labelText: tr('Password', 'كلمة المرور'),
                      border: const OutlineInputBorder(),
                      prefixIcon: const Icon(Icons.lock_outline),
                    ),
                    onSubmitted: (_) => _login(),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    tr('Default password: 12345', 'كلمة المرور الافتراضية: 12345'),
                    style: const TextStyle(color: accentGreen, fontWeight: FontWeight.bold),
                  ),
                  if (_error.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    Text(_error, style: const TextStyle(color: Colors.redAccent)),
                  ],
                  const SizedBox(height: 22),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: _login,
                      icon: const Icon(Icons.login),
                      label: Text(tr('LOGIN', 'دخول')),
                    ),
                  ),
                  TextButton.icon(
                    onPressed: () => languageArabic.value = !languageArabic.value,
                    icon: const Icon(Icons.language),
                    label: Text(tr('العربية', 'English')),
                  ),
                  TextButton(
                    onPressed: () => showAboutDialog(
                      context: context,
                      applicationName: 'Camera Security',
                      applicationVersion: '1.0.0',
                      applicationLegalese: tr('Developer: Hussein Al-Bayati • Instagram: @bgq_v', 'المطوّر: حسين البياتي • إنستغرام: @bgq_v'),
                    ),
                    child: Text(tr('About', 'حول')),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

enum ViewFilter { normal, blackWhite, nightVision }

class SecurityHome extends StatefulWidget {
  const SecurityHome({super.key});
  @override
  State<SecurityHome> createState() => _SecurityHomeState();
}

class _SecurityHomeState extends State<SecurityHome> with WidgetsBindingObserver {
  CameraController? _camera;
  List<CameraDescription> _cameras = [];
  CameraLensDirection _lensDirection = CameraLensDirection.back;
  late final FaceDetector _detector;
  final AudioPlayer _audio = AudioPlayer();
  bool _initializing = true;
  bool _streamBusy = false;
  bool _securityOn = false;
  bool _alarmEnabled = true;
  bool _capturing = false;
  int _faceCount = 0;
  final Map<int, FaceTrack> _faceTracks = {};
  int _nextFaceTrackId = 1;
  int _lastRotationDegrees = 0;
  ViewFilter _filter = ViewFilter.normal;
  List<Rect> _faces = [];
  Size _frameSize = Size.zero;
  String _status = 'Preparing camera...';
  List<File> _photos = [];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    languageArabic.addListener(_languageChanged);
    _detector = FaceDetector(
      options: FaceDetectorOptions(
        performanceMode: FaceDetectorMode.accurate,
        enableLandmarks: false,
        enableContours: false,
        enableClassification: false,
        enableTracking: true,
      ),
    );
    _start();
    _loadGallery();
  }

  void _languageChanged() { if (mounted) setState(() {}); }

  Future<Directory> _galleryDir() async {
    final docs = await getApplicationDocumentsDirectory();
    final dir = Directory('${docs.path}/CameraSecurity/Gallery');
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir;
  }

  Future<void> _loadGallery() async {
    try {
      final dir = await _galleryDir();
      final files = dir.listSync().whereType<File>()
          .where((f) => f.path.toLowerCase().endsWith('.jpg')).toList()
        ..sort((a, b) => b.path.compareTo(a.path));
      if (mounted) setState(() => _photos = files);
    } catch (_) {}
  }

  Future<void> _start({CameraLensDirection? preferredLens}) async {
    try {
      final status = await Permission.camera.request();
      if (!status.isGranted) {
        if (mounted) setState(() {
          _status = tr('Camera permission denied', 'لم يتم السماح باستخدام الكاميرا');
          _initializing = false;
        });
        return;
      }
      _cameras = await availableCameras();
      if (_cameras.isEmpty) throw Exception('No camera found');
      final wanted = preferredLens ?? _lensDirection;
      final matching = _cameras.where((c) => c.lensDirection == wanted).toList();
      final selected = matching.isNotEmpty ? matching.first : _cameras.first;
      _lensDirection = selected.lensDirection;
      final controller = CameraController(
        selected,
        ResolutionPreset.medium,
        enableAudio: false,
        imageFormatGroup: ImageFormatGroup.yuv420,
      );
      await controller.initialize();
      _camera = controller;
      await controller.startImageStream(_processFrame);
      if (mounted) setState(() {
        _initializing = false;
        _status = tr('Camera ready', 'الكاميرا جاهزة');
      });
    } catch (e) {
      if (mounted) setState(() {
        _initializing = false;
        _status = tr('Camera error: $e', 'خطأ بالكاميرا: $e');
      });
    }
  }

  InputImage? _inputImage(CameraImage image, CameraDescription camera) {
    try {
      // Convert YUV_420_888 to NV21 while respecting each plane's
      // rowStride and pixelStride (these vary between Android devices).
      if (image.planes.length < 3) return null;
      final width = image.width;
      final height = image.height;
      final yPlane = image.planes[0];
      final uPlane = image.planes[1];
      final vPlane = image.planes[2];
      final nv21 = Uint8List(width * height + (width * height ~/ 2));
      var index = 0;

      for (var row = 0; row < height; row++) {
        final rowStart = row * yPlane.bytesPerRow;
        for (var col = 0; col < width; col++) {
          final offset = rowStart + col * (yPlane.bytesPerPixel ?? 1);
          if (offset >= yPlane.bytes.length) return null;
          nv21[index++] = yPlane.bytes[offset];
        }
      }

      final uPixelStride = uPlane.bytesPerPixel ?? 1;
      final vPixelStride = vPlane.bytesPerPixel ?? 1;
      for (var row = 0; row < height ~/ 2; row++) {
        final uStart = row * uPlane.bytesPerRow;
        final vStart = row * vPlane.bytesPerRow;
        for (var col = 0; col < width ~/ 2; col++) {
          final uOffset = uStart + col * uPixelStride;
          final vOffset = vStart + col * vPixelStride;
          if (uOffset >= uPlane.bytes.length || vOffset >= vPlane.bytes.length) {
            return null;
          }
          nv21[index++] = vPlane.bytes[vOffset];
          nv21[index++] = uPlane.bytes[uOffset];
        }
      }

      final rotationCompensation = <DeviceOrientation, int>{
        DeviceOrientation.portraitUp: 0,
        DeviceOrientation.landscapeLeft: 90,
        DeviceOrientation.portraitDown: 180,
        DeviceOrientation.landscapeRight: 270,
      }[_camera?.value.deviceOrientation];
      if (rotationCompensation == null) return null;

      final rotationDegrees = camera.lensDirection == CameraLensDirection.front
          ? (camera.sensorOrientation + rotationCompensation) % 360
          : (camera.sensorOrientation - rotationCompensation + 360) % 360;
      final rotation = InputImageRotationValue.fromRawValue(rotationDegrees);
      if (rotation == null) return null;
      _lastRotationDegrees = rotationDegrees;

      final metadata = InputImageMetadata(
        size: Size(width.toDouble(), height.toDouble()),
        rotation: rotation,
        format: InputImageFormat.nv21,
        bytesPerRow: width,
      );
      return InputImage.fromBytes(bytes: nv21, metadata: metadata);
    } catch (e) {
      debugPrint('Image conversion error: $e');
      return null;
    }
  }

  double _intersectionOverUnion(Rect a, Rect b) {
    final intersection = a.intersect(b);
    if (intersection.isEmpty) return 0;
    final intersectionArea = intersection.width * intersection.height;
    final unionArea = a.width * a.height + b.width * b.height - intersectionArea;
    return unionArea <= 0 ? 0 : intersectionArea / unionArea;
  }

  List<FaceTrack> _updateFaceTracks(List<Face> faces) {
    final now = DateTime.now();
    _faceTracks.removeWhere(
      (_, track) => now.difference(track.lastSeen).inSeconds > 5,
    );

    final updated = <FaceTrack>[];
    final usedTrackIds = <int>{};
    for (final face in faces) {
      FaceTrack? track;
      final mlKitId = face.trackingId;

      if (mlKitId != null) {
        for (final candidate in _faceTracks.values) {
          if (candidate.mlKitId == mlKitId && !usedTrackIds.contains(candidate.id)) {
            track = candidate;
            break;
          }
        }
      }

      if (track == null && mlKitId == null) {
        var bestIou = 0.30;
        for (final candidate in _faceTracks.values) {
          if (usedTrackIds.contains(candidate.id)) continue;
          final overlap = _intersectionOverUnion(candidate.rect, face.boundingBox);
          if (overlap > bestIou) {
            bestIou = overlap;
            track = candidate;
          }
        }
      }

      track ??= FaceTrack(
        id: _nextFaceTrackId++,
        mlKitId: mlKitId,
        rect: face.boundingBox,
        lastSeen: now,
      );
      track
        ..mlKitId = mlKitId ?? track.mlKitId
        ..rect = face.boundingBox
        ..lastSeen = now;
      usedTrackIds.add(track.id);
      updated.add(track);
      _faceTracks[track.id] = track;
    }
    return updated;
  }

  Future<void> _processFrame(CameraImage image) async {
    if (_streamBusy || _camera == null || !_camera!.value.isInitialized) return;
    _streamBusy = true;
    try {
      final input = _inputImage(image, _camera!.description);
      if (input == null) {
        if (mounted) setState(() => _status = tr(
          'Face detection input unavailable',
          'تعذّر تجهيز صورة كشف الوجه',
        ));
        return;
      }

      final found = await _detector.processImage(input);
      final tracks = _updateFaceTracks(found);
      if (!mounted) return;

      final isQuarterTurn = _lastRotationDegrees == 90 ||
          _lastRotationDegrees == 270;
      final frameSize = isQuarterTurn
          ? Size(image.height.toDouble(), image.width.toDouble())
          : Size(image.width.toDouble(), image.height.toDouble());

      setState(() {
        _faceCount = found.length;
        _faces = found.map((face) => face.boundingBox).toList();
        _frameSize = frameSize;
        _status = found.isEmpty
            ? tr('Monitoring • No face detected', 'تجري المراقبة • لم يتم كشف وجه')
            : tr('Person detected • ${found.length}', 'تم كشف شخص • ${found.length}');
      });

      if (_securityOn && !_capturing && tracks.isNotEmpty) {
        var hasNewFace = false;
        for (final track in tracks) {
          if (!track.alarmTriggered) {
            track.alarmTriggered = true;
            hasNewFace = true;
          }
        }
        if (hasNewFace && _alarmEnabled) unawaited(_playFaceAlarm());

        // One successful photo every ~1.8 seconds, with a hard limit of
        // ten photos for each continuously tracked face.
        final eligible = tracks.where((track) =>
          track.photoCount < 10 &&
          DateTime.now().difference(track.lastPhotoAt).inMilliseconds >= 1800
        ).toList()
          ..sort((a, b) {
            final countOrder = a.photoCount.compareTo(b.photoCount);
            return countOrder != 0
                ? countOrder
                : a.lastPhotoAt.compareTo(b.lastPhotoAt);
          });

        if (eligible.isNotEmpty) {
          final track = eligible.first;
          final saved = await _capture(prefix: 'Face_${track.id}', silent: true);
          if (saved) {
            track.photoCount++;
            track.lastPhotoAt = DateTime.now();
            if (mounted) {
              setState(() => _status = tr(
                'Face ${track.id}: photo ${track.photoCount}/10 saved',
                'الوجه ${track.id}: تم حفظ الصورة ${track.photoCount}/10',
              ));
            }
          } else {
            track.lastPhotoAt = DateTime.now();
          }
        }
      }
    } catch (e) {
      debugPrint('Face detection frame error: $e');
      if (mounted) setState(() => _status = tr(
        'AI detection error: $e',
        'خطأ في كشف الوجوه: $e',
      ));
    } finally {
      _streamBusy = false;
    }
  }

  Future<void> _playFaceAlarm() async {
    if (!_alarmEnabled) return;
    try {
      await _audio.stop();
      await _audio.setVolume(1.0);
      await _audio.play(AssetSource('alarm.wav'), volume: 1.0);
    } catch (e) {
      debugPrint('Alarm error: $e');
    }
  }

  void _toggleAlarm() {
    setState(() => _alarmEnabled = !_alarmEnabled);
    if (!_alarmEnabled) unawaited(_audio.stop());
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(_alarmEnabled ? tr('Alarm sound enabled', 'تم تشغيل صوت الإنذار') : tr('Alarm muted • Detection remains active', 'تم كتم الإنذار • كاشف الوجوه ما زال يعمل'))),
    );
  }

  Future<Uint8List> _applyFilterToPhoto(Uint8List bytes) async {
    if (_filter == ViewFilter.normal) return bytes;
    final decoded = img.decodeImage(bytes);
    if (decoded == null) throw Exception('Could not decode captured photo');
    final oriented = img.bakeOrientation(decoded);
    final processed = img.Image.from(oriented);

    for (final pixel in processed) {
      final r = pixel.r.toDouble();
      final g = pixel.g.toDouble();
      final b = pixel.b.toDouble();
      if (_filter == ViewFilter.blackWhite) {
        final gray = (0.2126 * r + 0.7152 * g + 0.0722 * b).round().clamp(0, 255);
        pixel
          ..r = gray
          ..g = gray
          ..b = gray;
      } else if (_filter == ViewFilter.nightVision) {
        final luminance = 0.2126 * r + 0.7152 * g + 0.0722 * b;
        pixel
          ..r = (luminance * 0.08).round().clamp(0, 255)
          ..g = (luminance * 1.25 + 18).round().clamp(0, 255)
          ..b = (luminance * 0.12).round().clamp(0, 255);
      }
    }
    return Uint8List.fromList(img.encodeJpg(processed, quality: 92));
  }

  Future<bool> _capture({String prefix = 'Manual', bool silent = false}) async {
    final camera = _camera;
    if (camera == null || !camera.value.isInitialized || _capturing) return false;
    _capturing = true;
    try {
      if (camera.value.isStreamingImages) await camera.stopImageStream();
      await Future.delayed(const Duration(milliseconds: 250));
      final shot = await camera.takePicture();
      final dir = await _galleryDir();
      final stamp = DateTime.now().toIso8601String().replaceAll(':', '-');
      final outputBytes = await _applyFilterToPhoto(await File(shot.path).readAsBytes());
      final saved = File('${dir.path}/${prefix}_$stamp.jpg');
      await saved.writeAsBytes(outputBytes, flush: true);

      var deviceGallerySaved = false;
      try {
        final galleryPermission = await Gal.requestAccess(toAlbum: true);
        if (!galleryPermission) {
          throw Exception('Gallery permission was not granted');
        }
        await Gal.putImage(saved.path, album: 'Camera Security');
        deviceGallerySaved = true;
      } catch (galleryError) {
        debugPrint('Android gallery save error: $galleryError');
      }

      if (mounted) {
        setState(() {
          _photos.insert(0, saved);
          _status = deviceGallerySaved
              ? tr('Photo saved to phone gallery', 'تم حفظ الصورة في معرض الهاتف')
              : tr('Photo saved inside app; phone gallery permission unavailable', 'حُفظت الصورة داخل التطبيق؛ تعذّر الوصول لمعرض الهاتف');
        });
        if (!silent) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(deviceGallerySaved
                ? tr('Photo saved to Camera Security album', 'تم حفظ الصورة في ألبوم Camera Security')
                : tr('Saved in app gallery only. Check photo permission.', 'حُفظت داخل التطبيق فقط. تحقق من إذن الصور.'))),
          );
        }
      }
      return true;
    } catch (e) {
      if (mounted) setState(() => _status = tr('Capture error: $e', 'خطأ في التقاط الصورة: $e'));
      return false;
    } finally {
      try {
        if (mounted && camera.value.isInitialized && !camera.value.isStreamingImages) {
          await camera.startImageStream(_processFrame);
        }
      } catch (e) {
        debugPrint('Could not restart camera stream: $e');
      }
      _capturing = false;
    }
  }

  Future<void> _manualCapture() async {
    if (_capturing) return;
    for (var i = 3; i > 0; i--) {
      if (!mounted) return;
      setState(() => _status = tr('Capture in $i...', 'التقاط الصورة بعد $i...'));
      await Future.delayed(const Duration(seconds: 1));
    }
    await _capture();
  }

  Future<void> _switchCamera() async {
    if (_initializing || _capturing) return;
    final next = _lensDirection == CameraLensDirection.back
        ? CameraLensDirection.front : CameraLensDirection.back;
    setState(() { _initializing = true; _faces = []; _faceCount = 0; _faceTracks.clear(); _status = tr('Switching camera...', 'جارٍ تبديل الكاميرا...'); });
    final old = _camera;
    _camera = null;
    try {
      if (old != null) {
        if (old.value.isStreamingImages) await old.stopImageStream();
        await old.dispose();
      }
    } catch (e) { debugPrint('Camera dispose error: $e'); }
    await _start(preferredLens: next);
  }

  void _toggleSecurity() {
    setState(() {
      _securityOn = !_securityOn;
      _status = _securityOn ? tr('Security enabled - monitoring faces', 'تم تفعيل الحماية - مراقبة الوجوه') : tr('Security disabled', 'تم إيقاف الحماية');
    });
  }

  Future<void> _changePassword() async {
    final field = TextEditingController();
    final value = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(tr('Change password', 'تغيير كلمة المرور')),
        content: TextField(
          controller: field,
          obscureText: true,
          decoration: InputDecoration(hintText: tr('New password', 'كلمة المرور الجديدة')),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: Text(tr('Cancel', 'إلغاء'))),
          FilledButton(onPressed: () => Navigator.pop(context, field.text.trim()), child: Text(tr('Save', 'حفظ'))),
        ],
      ),
    );
    if (value != null && value.isNotEmpty) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('app_password_v2', value);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(tr('Password updated', 'تم تحديث كلمة المرور'))),
      );
    }
    field.dispose();
  }

  void _showGallery() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => SafeArea(
        child: SizedBox(
          height: MediaQuery.of(context).size.height * .75,
          child: _photos.isEmpty
              ? Center(child: Text(tr('No photos yet', 'لا توجد صور بعد')))
              : GridView.builder(
                  padding: const EdgeInsets.all(12),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2, crossAxisSpacing: 10, mainAxisSpacing: 10,
                  ),
                  itemCount: _photos.length,
                  itemBuilder: (sheetContext, i) => InkWell(
                    onTap: () {
                      final selectedPhoto = _photos[i];
                      Navigator.pop(sheetContext);
                      Future.delayed(Duration.zero, () {
                        if (mounted) {
                          Navigator.of(context).push(MaterialPageRoute(
                            builder: (_) => PhotoViewerPage(file: selectedPhoto),
                          ));
                        }
                      });
                    },
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: Image.file(_photos[i], fit: BoxFit.cover),
                    ),
                  ),
                ),
        ),
      ),
    );
  }

  ColorFilter? get _colorFilter {
    switch (_filter) {
      case ViewFilter.normal:
        return null;
      case ViewFilter.blackWhite:
        return const ColorFilter.matrix(<double>[
          0.2126, 0.7152, 0.0722, 0, 0,
          0.2126, 0.7152, 0.0722, 0, 0,
          0.2126, 0.7152, 0.0722, 0, 0,
          0, 0, 0, 1, 0,
        ]);
      case ViewFilter.nightVision:
        return const ColorFilter.matrix(<double>[
          0.10, 0.20, 0.05, 0, 0,
          0.25, 1.20, 0.10, 0, 0,
          0.05, 0.35, 0.08, 0, 0,
          0, 0, 0, 1, 0,
        ]);
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final camera = _camera;
    if (camera == null) return;
    if (state == AppLifecycleState.inactive || state == AppLifecycleState.paused) {
      camera.dispose();
      _camera = null;
    } else if (state == AppLifecycleState.resumed) {
      _start();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    languageArabic.removeListener(_languageChanged);
    _camera?.dispose();
    _detector.close();
    _audio.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final camera = _camera;
    return Scaffold(
      appBar: AppBar(
        title: Text(tr('◈ CAMERA SECURITY', '◈ نظام المراقبة الأمنية'), style: const TextStyle(color: cyberBlue, fontWeight: FontWeight.bold, letterSpacing: 1.1)),
        actions: [
          IconButton(tooltip: tr('Switch language', 'تغيير اللغة'), onPressed: () => languageArabic.value = !languageArabic.value, icon: const Icon(Icons.language)),
          IconButton(
            tooltip: tr('About', 'حول'),
            onPressed: () => showAboutDialog(
              context: context,
              applicationName: 'Camera Security',
              applicationVersion: '1.0.0',
              applicationLegalese: tr('Developer: Hussein Al-Bayati • Instagram: @bgq_v', 'المطوّر: حسين البياتي • إنستغرام: @bgq_v'),
            ),
            icon: const Icon(Icons.info_outline),
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 6, 14, 10),
              child: Row(
                children: [
                  Icon(Icons.circle, size: 11, color: _securityOn ? accentGreen : Colors.redAccent),
                  const SizedBox(width: 8),
                  Expanded(child: Text(_securityOn ? tr('SECURITY ON', 'الحماية مفعّلة') : tr('SECURITY OFF', 'الحماية متوقفة'),
                      style: const TextStyle(fontWeight: FontWeight.bold, color: cyberBlue))),
                  Text('${tr('AI FACES', 'وجوه AI')}: $_faceCount', style: const TextStyle(color: accentGreen, fontWeight: FontWeight.bold)),
                ],
              ),
            ),
            Expanded(
              child: Container(
                margin: const EdgeInsets.symmetric(horizontal: 12),
                decoration: BoxDecoration(
                  color: Colors.black,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: cyberBlue.withValues(alpha: .65), width: 1.4),
                ),
                clipBehavior: Clip.antiAlias,
                child: _initializing
                    ? const Center(child: CircularProgressIndicator())
                    : camera != null && camera.value.isInitialized
                        ? Stack(
                            fit: StackFit.expand,
                            children: [
                              _colorFilter == null
                                  ? CameraPreview(camera)
                                  : ColorFiltered(
                                      colorFilter: _colorFilter!,
                                      child: CameraPreview(camera),
                                    ),
                              if (_faces.isNotEmpty && _frameSize != Size.zero)
                                CustomPaint(painter: FaceBoxPainter(_faces, _frameSize, mirror: _lensDirection == CameraLensDirection.front)),
                              if (_faceCount > 0)
                                Positioned(
                                  top: 14, left: 14,
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                                    decoration: BoxDecoration(color: Colors.black.withValues(alpha: .78), border: Border.all(color: Colors.redAccent), borderRadius: BorderRadius.circular(8)),
                                    child: Text(tr('AI • FACE DETECTED', 'ذكاء اصطناعي • تم كشف وجه'), style: const TextStyle(color: Colors.redAccent, fontWeight: FontWeight.bold)),
                                  ),
                                ),
                            ],
                          )
                        : Center(
                            child: Padding(
                              padding: const EdgeInsets.all(20),
                              child: Text(_status, textAlign: TextAlign.center),
                            ),
                          ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 12, 14, 4),
              child: Text(_status, maxLines: 2, textAlign: TextAlign.center,
                  style: const TextStyle(color: cyberBlue, fontWeight: FontWeight.w600)),
            ),
            Padding(
              padding: const EdgeInsets.all(12),
              child: Wrap(
                alignment: WrapAlignment.center,
                spacing: 8,
                runSpacing: 8,
                children: [
                  FilledButton.icon(
                    onPressed: _toggleSecurity,
                    icon: Icon(_securityOn ? Icons.shield : Icons.shield_outlined),
                    label: Text(_securityOn ? tr('Security ON', 'الحماية مفعّلة') : tr('Security OFF', 'تفعيل الحماية')),
                    style: FilledButton.styleFrom(
                      backgroundColor: _securityOn ? Colors.green.shade800 : Colors.red.shade900,
                    ),
                  ),
                  OutlinedButton.icon(
                    onPressed: _initializing ? null : _switchCamera,
                    icon: const Icon(Icons.cameraswitch),
                    label: Text(tr('Flip camera', 'قلب الكاميرا')),
                  ),
                  OutlinedButton.icon(
                    onPressed: _toggleAlarm,
                    icon: Icon(_alarmEnabled ? Icons.volume_up : Icons.volume_off),
                    label: Text(_alarmEnabled ? tr('Alarm sound ON', 'صوت الإنذار يعمل') : tr('Alarm muted', 'كتم الإنذار')),
                    style: OutlinedButton.styleFrom(foregroundColor: _alarmEnabled ? accentGreen : cyberBlue, side: BorderSide(color: _alarmEnabled ? accentGreen : cyberBlue)),
                  ),
                  FilledButton.icon(
                    onPressed: _capturing ? null : _manualCapture,
                    icon: const Icon(Icons.camera_alt),
                    label: Text(tr('Capture', 'التقاط صورة')),
                  ),
                  OutlinedButton.icon(
                    onPressed: _showGallery,
                    icon: const Icon(Icons.photo_library_outlined),
                    label: Text(tr('Gallery', 'المعرض')),
                  ),
                  OutlinedButton.icon(
                    onPressed: _changePassword,
                    icon: const Icon(Icons.password),
                    label: Text(tr('Password', 'كلمة المرور')),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(bottom: 14, left: 12, right: 12),
              child: SegmentedButton<ViewFilter>(
                segments: [
                  ButtonSegment(value: ViewFilter.normal, label: Text(tr('Normal', 'عادي'))),
                  ButtonSegment(value: ViewFilter.blackWhite, label: Text(tr('B&W', 'أبيض وأسود'))),
                  ButtonSegment(value: ViewFilter.nightVision, label: Text(tr('Night', 'ليلي'))),
                ],
                selected: {_filter},
                onSelectionChanged: (s) => setState(() => _filter = s.first),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class PhotoViewerPage extends StatelessWidget {
  const PhotoViewerPage({super.key, required this.file});
  final File file;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF05090F),
      appBar: AppBar(
        title: Text(tr('PHOTO VIEWER', 'عرض الصورة')),
      ),
      body: Center(
        child: InteractiveViewer(
          minScale: 0.8,
          maxScale: 5,
          child: Image.file(
            file,
            fit: BoxFit.contain,
            errorBuilder: (_, error, __) => Center(
              child: Text(tr('Could not open this photo', 'تعذّر فتح هذه الصورة')),
            ),
          ),
        ),
      ),
    );
  }
}

class FaceTrack {
  FaceTrack({
    required this.id,
    required this.mlKitId,
    required this.rect,
    required this.lastSeen,
  });

  final int id;
  int? mlKitId;
  Rect rect;
  DateTime lastSeen;
  int photoCount = 0;
  DateTime lastPhotoAt = DateTime.fromMillisecondsSinceEpoch(0);
  bool alarmTriggered = false;
}

class FaceBoxPainter extends CustomPainter {
  FaceBoxPainter(this.faces, this.sourceSize, {required this.mirror});

  final List<Rect> faces;
  final Size sourceSize;
  final bool mirror;

  @override
  void paint(Canvas canvas, Size size) {
    if (sourceSize.width <= 0 || sourceSize.height <= 0) return;
    final sx = size.width / sourceSize.width;
    final sy = size.height / sourceSize.height;
    final scale = sx > sy ? sx : sy;
    final dx = (size.width - sourceSize.width * scale) / 2;
    final dy = (size.height - sourceSize.height * scale) / 2;

    final line = Paint()
      ..color = accentGreen
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.5
      ..strokeCap = StrokeCap.round;
    final glow = Paint()
      ..color = cyberBlue.withValues(alpha: .24)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 7;

    for (final face in faces) {
      var left = face.left;
      var right = face.right;
      if (mirror) {
        final oldLeft = left;
        left = sourceSize.width - right;
        right = sourceSize.width - oldLeft;
      }

      final rect = Rect.fromLTRB(
        left * scale + dx,
        face.top * scale + dy,
        right * scale + dx,
        face.bottom * scale + dy,
      );
      final rounded = RRect.fromRectAndRadius(
        rect,
        Radius.circular((rect.width * .08).clamp(5.0, 14.0)),
      );
      canvas.drawRRect(rounded, glow);
      canvas.drawRRect(rounded, line);

      final corner = (rect.shortestSide * .22).clamp(12.0, 28.0);
      final corners = <Path>[
        Path()..moveTo(rect.left, rect.top + corner)..lineTo(rect.left, rect.top)..lineTo(rect.left + corner, rect.top),
        Path()..moveTo(rect.right - corner, rect.top)..lineTo(rect.right, rect.top)..lineTo(rect.right, rect.top + corner),
        Path()..moveTo(rect.left, rect.bottom - corner)..lineTo(rect.left, rect.bottom)..lineTo(rect.left + corner, rect.bottom),
        Path()..moveTo(rect.right - corner, rect.bottom)..lineTo(rect.right, rect.bottom)..lineTo(rect.right, rect.bottom - corner),
      ];
      for (final path in corners) {
        canvas.drawPath(path, Paint()
          ..color = accentGreen
          ..style = PaintingStyle.stroke
          ..strokeWidth = 4
          ..strokeCap = StrokeCap.square);
      }

      final label = TextPainter(
        textDirection: TextDirection.ltr,
        text: const TextSpan(
          text: 'FACE • TRACKING',
          style: TextStyle(
            color: accentGreen,
            fontSize: 10,
            fontWeight: FontWeight.bold,
            letterSpacing: 1.1,
          ),
        ),
      )..layout();
      final labelY = (rect.top - label.height - 7).clamp(0.0, size.height);
      final labelBg = Rect.fromLTWH(
        rect.left, labelY, label.width + 10, label.height + 5,
      );
      canvas.drawRect(labelBg, Paint()..color = const Color(0xDD06131A));
      label.paint(canvas, Offset(rect.left + 5, labelY + 2));
    }
  }

  @override
  bool shouldRepaint(covariant FaceBoxPainter oldDelegate) =>
      oldDelegate.faces != faces ||
      oldDelegate.sourceSize != sourceSize ||
      oldDelegate.mirror != mirror;
}
